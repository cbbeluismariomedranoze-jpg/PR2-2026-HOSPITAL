from tkinter import *

from RepPacientes import RepPacientes
from RepDoctores import RepDoctores
from RepReservas import RepReservas
from RepAtenciones import RepAtenciones
from RepCirugias import RepCirugias
from RepLaboratorios import RepLaboratorios
from RepDiagnosticos import RepDiagnosticos
from RepKardex import RepKardex
from RepQuirofanos import RepQuirofanos
from RepConsultorios import RepConsultorios
from RepEnfermeras import RepEnfermeras
from RepUsuarios import RepUsuarios

COLOR_FONDO = "#F4F8FC"
COLOR_AZUL_OSCURO = "#174EA6"
COLOR_AZUL = "#2563EB"
COLOR_AZUL_CLARO = "#EAF3FF"
COLOR_AZUL_HOVER = "#DCEBFF"
COLOR_BLANCO = "#FFFFFF"
COLOR_TEXTO = "#172B4D"
COLOR_SECUNDARIO = "#718096"
COLOR_BORDE = "#DCE6F2"


FUENTE_TITULO = ("Segoe UI", 22, "bold")
FUENTE_SUBTITULO = ("Segoe UI", 10)
FUENTE_TARJETA = ("Segoe UI", 12, "bold")
FUENTE_DESCRIPCION = ("Segoe UI", 9)


class MenuReportes:

    def __init__(self, ventana, al_cerrar=None):

        self.ventana = ventana
        self.al_cerrar = al_cerrar
        self.ventana.title("Reportes del Sistema")

        self.ventana.resizable(False, False)

        ancho = 1100
        alto = 700

        pantalla_ancho = self.ventana.winfo_screenwidth()
        pantalla_alto = self.ventana.winfo_screenheight()

        x = (pantalla_ancho // 2) - (ancho // 2)
        y = (pantalla_alto // 2) - (alto // 2)

        self.ventana.geometry(f"{ancho}x{alto}+{x}+{y}")

        self.ventana.configure(bg=COLOR_FONDO)

        self.crear_interfaz()

    def crear_interfaz(self):

        franja = Frame(self.ventana, bg=COLOR_AZUL, height=5)

        franja.pack(fill="x")

        barra = Frame(self.ventana, bg=COLOR_BLANCO, height=70)

        barra.pack(fill="x")

        barra.pack_propagate(False)

        logo = Frame(barra, bg=COLOR_BLANCO)

        logo.pack(side=LEFT, padx=35)

        Label(logo, text="▤", bg=COLOR_BLANCO, fg=COLOR_AZUL, font=("Segoe UI", 27, "bold")).pack(
            side=LEFT, padx=(0, 10)
        )

        texto_logo = Frame(logo, bg=COLOR_BLANCO)

        texto_logo.pack(side=LEFT)

        Label(
            texto_logo,
            text="Hospital Privado",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 17, "bold"),
        ).pack(anchor="w")

        Label(
            texto_logo,
            text="Sistema de gestión hospitalaria",
            bg=COLOR_BLANCO,
            fg=COLOR_SECUNDARIO,
            font=("Segoe UI", 8),
        ).pack(anchor="w")

        contenido = Frame(self.ventana, bg=COLOR_FONDO)

        contenido.pack(fill=BOTH, expand=True, padx=45, pady=25)

        Label(
            contenido,
            text="Reportes del sistema",
            bg=COLOR_FONDO,
            fg=COLOR_TEXTO,
            font=FUENTE_TITULO,
        ).pack(anchor="w")

        Label(
            contenido,
            text="Consulta y genera reportes de la información registrada.",
            bg=COLOR_FONDO,
            fg=COLOR_SECUNDARIO,
            font=FUENTE_SUBTITULO,
        ).pack(anchor="w", pady=(3, 18))

        tarjetas = Frame(contenido, bg=COLOR_FONDO)

        tarjetas.pack(fill=BOTH, expand=True)

        for columna in range(3):

            tarjetas.columnconfigure(columna, weight=1)

        for fila in range(2):

            tarjetas.rowconfigure(fila, weight=1)

        self.crear_tarjeta(
            tarjetas,
            0,
            0,
            "🧑‍⚕️",
            "Pacientes",
            "Reporte de pacientes registrados.",
            self.abrir_pacientes,
        )

        self.crear_tarjeta(
            tarjetas,
            0,
            1,
            "👨‍⚕️",
            "Doctores",
            "Reporte de doctores registrados.",
            self.abrir_doctores,
        )

        self.crear_tarjeta(
            tarjetas, 0, 2, "📅", "Reservas", "Reporte de reservas realizadas.", self.abrir_reservas
        )

        self.crear_tarjeta(
            tarjetas,
            1,
            0,
            "🩺",
            "Atenciones",
            "Reporte de atenciones médicas.",
            self.abrir_atenciones,
        )

        self.crear_tarjeta(
            tarjetas,
            1,
            1,
            "🏥",
            "Cirugías",
            "Reporte de procedimientos quirúrgicos.",
            self.abrir_cirugias,
        )

        self.crear_tarjeta(
            tarjetas,
            1,
            2,
            "🧪",
            "Laboratorios",
            "Reporte de resultados de laboratorio.",
            self.abrir_laboratorios,
        )

        botones = Frame(contenido, bg=COLOR_FONDO)

        botones.pack(fill="x", pady=(15, 0))

        Button(
            botones,
            text="▦  Más reportes",
            bg=COLOR_AZUL,
            fg=COLOR_BLANCO,
            activebackground=COLOR_AZUL_OSCURO,
            activeforeground=COLOR_BLANCO,
            relief="flat",
            bd=0,
            cursor="hand2",
            font=("Segoe UI", 10, "bold"),
            padx=18,
            pady=8,
            command=self.otros_reportes,
        ).pack(side=LEFT)

        Button(
            botones,
            text="←  Volver",
            bg=COLOR_BLANCO,
            fg=COLOR_SECUNDARIO,
            activebackground="#E2E8F0",
            activeforeground=COLOR_TEXTO,
            relief="solid",
            bd=1,
            cursor="hand2",
            font=("Segoe UI", 10, "bold"),
            padx=18,
            pady=7,
            command=self.cerrar,
        ).pack(side=RIGHT)

    def crear_tarjeta(self, contenedor, fila, columna, icono, titulo, descripcion, comando):

        tarjeta = Frame(
            contenedor,
            bg=COLOR_BLANCO,
            highlightbackground=COLOR_BORDE,
            highlightthickness=1,
            cursor="hand2",
        )

        tarjeta.grid(row=fila, column=columna, padx=10, pady=10, sticky="nsew")

        contenido = Frame(tarjeta, bg=COLOR_BLANCO, cursor="hand2")

        contenido.pack(fill=BOTH, expand=True, padx=20, pady=15)

        icono_frame = Frame(contenido, bg=COLOR_AZUL_CLARO, width=55, height=55, cursor="hand2")

        icono_frame.pack(anchor="w")

        icono_frame.pack_propagate(False)

        Label(
            icono_frame,
            text=icono,
            bg=COLOR_AZUL_CLARO,
            font=("Segoe UI Emoji", 23),
            cursor="hand2",
        ).pack(expand=True)

        Label(
            contenido,
            text=titulo,
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=FUENTE_TARJETA,
            cursor="hand2",
        ).pack(anchor="w", pady=(12, 3))

        Label(
            contenido,
            text=descripcion,
            bg=COLOR_BLANCO,
            fg=COLOR_SECUNDARIO,
            font=FUENTE_DESCRIPCION,
            cursor="hand2",
            wraplength=280,
            justify=LEFT,
        ).pack(anchor="w")

        Label(
            contenido,
            text="Generar  →",
            bg=COLOR_BLANCO,
            fg=COLOR_AZUL,
            font=("Segoe UI", 9, "bold"),
            cursor="hand2",
        ).pack(anchor="e", pady=(8, 0))

        widgets = (
            [tarjeta, contenido, icono_frame]
            + list(contenido.winfo_children())
            + list(icono_frame.winfo_children())
        )

        for widget in widgets:

            widget.bind("<Button-1>", lambda e, cmd=comando: cmd())

            widget.bind("<Enter>", lambda e, t=tarjeta: self.hover_tarjeta(t))

            widget.bind("<Leave>", lambda e, t=tarjeta: self.normal_tarjeta(t))

    def hover_tarjeta(self, tarjeta):

        tarjeta.configure(bg=COLOR_AZUL_HOVER, highlightbackground=COLOR_AZUL)

        for widget in tarjeta.winfo_children():

            widget.configure(bg=COLOR_AZUL_HOVER)

            for hijo in widget.winfo_children():

                try:
                    hijo.configure(bg=COLOR_AZUL_HOVER)
                except:
                    pass

    def normal_tarjeta(self, tarjeta):

        tarjeta.configure(bg=COLOR_BLANCO, highlightbackground=COLOR_BORDE)

        for widget in tarjeta.winfo_children():

            widget.configure(bg=COLOR_BLANCO)

            for hijo in widget.winfo_children():

                try:
                    if widget == tarjeta.winfo_children()[1]:
                        hijo.configure(bg=COLOR_BLANCO)
                    else:
                        hijo.configure(bg=COLOR_AZUL_CLARO)
                except:
                    pass

    def cerrar(self):
        if self.al_cerrar:
            self.al_cerrar()
        else:
            self.ventana.destroy()

    def abrir_pacientes(self):

        ventana = Toplevel()

        RepPacientes(ventana)

    def abrir_doctores(self):

        ventana = Toplevel()

        RepDoctores(ventana)

    def abrir_reservas(self):

        ventana = Toplevel()

        RepReservas(ventana)

    def abrir_atenciones(self):

        ventana = Toplevel()

        RepAtenciones(ventana)

    def abrir_cirugias(self):

        ventana = Toplevel()

        RepCirugias(ventana)

    def abrir_laboratorios(self):

        ventana = Toplevel()

        RepLaboratorios(ventana)

    def otros_reportes(self):

        ventana = Toplevel()

        ventana.title("Más Reportes")

        ventana.resizable(False, False)

        ancho = 650
        alto = 520

        pantalla_ancho = ventana.winfo_screenwidth()
        pantalla_alto = ventana.winfo_screenheight()

        x = (pantalla_ancho // 2) - (ancho // 2)
        y = (pantalla_alto // 2) - (alto // 2)

        ventana.geometry(f"{ancho}x{alto}+{x}+{y}")

        ventana.configure(bg=COLOR_FONDO)

        franja = Frame(ventana, bg=COLOR_AZUL, height=5)

        franja.pack(fill="x")

        Label(
            ventana,
            text="Más reportes",
            bg=COLOR_FONDO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 20, "bold"),
        ).pack(anchor="w", padx=35, pady=(25, 3))

        Label(
            ventana,
            text="Selecciona el reporte que deseas consultar.",
            bg=COLOR_FONDO,
            fg=COLOR_SECUNDARIO,
            font=("Segoe UI", 10),
        ).pack(anchor="w", padx=35, pady=(0, 20))

        tarjetas = Frame(ventana, bg=COLOR_FONDO)

        tarjetas.pack(fill=BOTH, expand=True, padx=25, pady=5)

        for columna in range(2):

            tarjetas.columnconfigure(columna, weight=1)

        for fila in range(3):

            tarjetas.rowconfigure(fila, weight=1)

        opciones = [
            ("📋", "Diagnósticos", RepDiagnosticos),
            ("📦", "Kardex", RepKardex),
            ("🚪", "Quirófanos", RepQuirofanos),
            ("🏢", "Consultorios", RepConsultorios),
            ("👩‍⚕️", "Enfermeras", RepEnfermeras),
            ("👤", "Usuarios", RepUsuarios),
        ]

        for i, (icono, titulo, clase) in enumerate(opciones):

            fila = i // 2
            columna = i % 2

            tarjeta = Frame(
                tarjetas,
                bg=COLOR_BLANCO,
                highlightbackground=COLOR_BORDE,
                highlightthickness=1,
                cursor="hand2",
            )

            tarjeta.grid(row=fila, column=columna, padx=8, pady=8, sticky="nsew")

            def abrir(clase=clase):

                nueva_ventana = Toplevel()

                clase(nueva_ventana)

            Label(
                tarjeta, text=icono, bg=COLOR_BLANCO, font=("Segoe UI Emoji", 22), cursor="hand2"
            ).pack(side=LEFT, padx=(15, 8), pady=15)

            Label(
                tarjeta,
                text=titulo,
                bg=COLOR_BLANCO,
                fg=COLOR_TEXTO,
                font=("Segoe UI", 10, "bold"),
                cursor="hand2",
            ).pack(side=LEFT)

            for widget in tarjeta.winfo_children():

                widget.bind("<Button-1>", lambda e, cmd=abrir: cmd())

        Button(
            ventana,
            text="Cerrar",
            bg=COLOR_BLANCO,
            fg=COLOR_SECUNDARIO,
            activebackground="#E2E8F0",
            activeforeground=COLOR_TEXTO,
            relief="solid",
            bd=1,
            cursor="hand2",
            font=("Segoe UI", 10, "bold"),
            padx=20,
            pady=7,
            command=ventana.destroy,
        ).pack(anchor="e", padx=35, pady=20)


def menu_reportes(ventana, al_cerrar=None):
    return MenuReportes(ventana, al_cerrar)


if __name__ == "__main__":

    ventana = Tk()
    menu_reportes(ventana)
    ventana.mainloop()
